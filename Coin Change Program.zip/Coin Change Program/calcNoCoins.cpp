#include<iostream>
#include<sstream>
#include<fstream>
#include<vector>
#include<string>
#include<algorithm>
#include<numeric>
#include<iterator>
#include<chrono>
#include "Algo.h"
using namespace std;
typedef Result (*Algorithm)(const int &, const vector<int>&);
typedef pair<vector<int>, vector<int> > Input;
int main(int argc, char *argv[]) {
	if(argc != 4) {
		cout<<"Usage: "<<argv[0]<<" algo_id[1|2|3] <input> <logfile>"<<endl;
		return -1;
	}
	int algo_no = atoi(argv[1]);	        //The id of the algorithm to execute, 1: changeslow 2: changegreedy 3:changedp
    ifstream inputfile(argv[2], ios::in);   //Input file
	ofstream logfile(argv[3], ios::out);    //An output file where a line contains the amount and the number of coins used

	Algorithm f;					//A pointer to the algorithm to execute
    switch(algo_no) {
        case 1: 
            f = changeslow; break;
	    case 2:
            f = changegreedy; break;
        case 3:
            f = changedp; break;
        default:
            cout<<"Invalid algorithm id: "<<algo_no<<endl;
            return -1;
	}
    
    Result res;
    vector<Input> inputs;
    int duration = 0;

	//Read from the input file and store in a vector
	string line;
    int n;
    vector<int> coins;
    vector<int> StartStepEnd;

    //Read the coins and the start, step and end of the amounts    
    while(getline(inputfile, line)){		
		if(line.size() > 1){

			stringstream ss(line);
			while(ss>>n){
				coins.push_back(n);
				ss.ignore(1, ','); //skip the comma
			}
            
            getline(inputfile, line);   //Read the start, step and End
			stringstream ss2(line);
			
            ss2>>n;         //Read Starting number
			StartStepEnd.push_back(n);
            ss2.ignore(1, ','); //skip the comma
            
            ss2>>n;         //Read Step
			StartStepEnd.push_back(n);
            ss2.ignore(1, ','); //skip the comma
            
            ss2>>n;
			StartStepEnd.push_back(n);  //Read end
            ss2.ignore(1, ','); //skip the comma

            inputs.push_back(make_pair(coins, StartStepEnd));

            coins.clear();
            StartStepEnd.clear();
		}
    }

    vector<int> V1{1, 5, 10, 25, 50};
    
    //*******WARMUP RUN************** 
    for(int i = 2010; i <= 2200; i += 5){
        duration = 0;
        for(int k = 0; k < 10; ++k) {
            res = f(i, V1);
        }
    }    
    //************END OF WARMUP RUN ************
    
    int start, step, end;
    for(auto it = inputs.begin(); it != inputs.end(); ++it){
        copy(it->first.begin(), it->first.end(), ostream_iterator<int>(logfile, " "));
        logfile<<endl;
        logfile<<"\tAmount\tNo. Coins\tRunning time in microseconds\n";
        
        start = it->second.at(0);
        step = it->second.at(1);
        end = it->second.at(2);
        
        for(int i = start; i <= end; i += step){
            duration = 0;
            for(int k = 0; k < 10; ++k) {
                auto start =  chrono::high_resolution_clock::now();
                res = f(i, V1);
                auto end = chrono::high_resolution_clock::now();
                
                duration += chrono::duration_cast<chrono::microseconds>(end-start).count();        
            }

            logfile<<"\t"<<i<<"\t"<<res.first<<"\t"<<(double)duration/10<<endl;
        }    
    }
    
	return 0;
}
