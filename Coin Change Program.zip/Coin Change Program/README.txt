Compilation and running:
    $ chmod +x compile.sh       % make the script executable
    $ ./compile.sh              % generates exeMain, exeCalcNoCoins 
    $ ./exeMain <algo_id[1:changeSlow, 2:changeGreedy, 3: changedp]> <input file>     % run the selected algorithm on the input
    
    $. /exeCalcNoCoins <algo_id[1:changeSlow, 2:changeGreedy, 3: changedp]> <inputfile>  <outfile> 
        //inputfile must be formated as sampleinput_calcNoCoins.txt
            eg.
             line1:  1, 2, 5, 10, 15 ====> V[1,2, 5,10,15]
             line2:  2005,5,2200  =====> [2005, 2010, 2015,...2200]
                
        //outfile will be formated as sampleoutput_calcNoCoins.txt

    We can easily arrange the necessary input for questions 3-6 and plot the charts using the data in the output file
