#include<iostream>
#include<vector>
#include<limits>
#include<iterator>
#include<numeric>
#include "Algo.h"
static std::vector<int> changeslowDC(const int coins [], int changeRequested, int coinsSize);
static int elementSum(std::vector<int> vect1, std::vector<int> vect2);

Result changegreedy(const int &A, const std::vector<int> &coins){
    int amount = A;
    int n = coins.size(); 
    //v = value array containing the number of each type of coin
    std::vector<int>v(n, 0); 

    int cnt = 0;  //used to hold the number of coins used to make change
    int nCoins = 0;
    int k = n;   //used to store current index

    //start at the end of the c[] array, working backwards.. selecting highest denomination
    while (amount) {
        k--;
        cnt = 0;
        //while the denomination is less than the amount, keep subtracting
        while(coins.at(k) <= amount){
            amount = amount - coins.at(k);
            cnt++;
        }
        //store number of each coin used in v[]
        v.at(k) = cnt;
        nCoins += cnt;
    }

    return std::make_pair(nCoins, v);
}
Result changedp(const int &A, const std::vector<int> &coins){
    std::vector<int> optS(coins.size(), 0);
    int optV;

    std::vector<int> T(A+1, 0);    //A table to store the values of the optimal solutions to the subproblems
    std::vector<int> C(A+1, 0);    //A table to store the coin denominations used

	int j, q, k;
	
    for(int i = 1; i <=A; ++i){ //Build optimal solutions' values for subproblems
		j = 0;
        k = 0;
        q = std::numeric_limits<int>::max();     //Positive 'infinity'
        //While there are coins and the current coin is less than or equal to the current amount	
		while (j < coins.size() && coins.at(j) <= i){		
            if(T.at(i-coins.at(j)) + 1 <= q){
				q = T.at(i - coins.at(j)) + 1;      //Current optimal solution
                k = j;                              //The index of the coin denomination used in the current optimal solution
			}
			j++;
		}
        C.at(i) = k;     //Store the index of the coin denomination d used for the amount i in the expression T[i] = T[i-d] + 1
        T.at(i) = q;     //Store the value of the optimal solution of i;
	}
    //Calculate optimal solutions
    int n = A;
    while(n > 0) {
        k = C.at(n);
        optS.at(k)++;
        n -= coins.at(k);        
    }
    return std::make_pair(T.at(A), optS);
}

Result changeslow(const int &A, const std::vector<int> &coins){
    std::vector<int> result(coins.size(), 0);
    std::vector<int> res = changeslowDC(coins.data(), A, coins.size());
    
    int minCoins = 0;
                
    //Place each value from vector into result array
    for(int i = 0; i < coins.size(); i++)
    {
        result.at(i) = res.at(i);
        minCoins += res.at(i); //Sum of coins used
    }

    return std::make_pair(minCoins, result);
}

/****************************************************************************************
 ** Description: Calculates the minimum number of coins used for a given change value
 ** Parameters:  int coins[], int coinsSize, int changeRequested, int &minCoins
 ** Pre-Conditions: coins[] must contain coin values with at least a "1" coin
 ** Post-Conditions: Returns a vector containing count of each coin used
 ****************************************************************************************/
static std::vector<int> changeslowDC(const int coins [], int changeRequested, int coinsSize) {
    std::vector<int> coinCount (coinsSize, 0); //Holds count of each coin used. Initialized to 0
    //Check for change of 0
    if(changeRequested == 0)
        return coinCount;
    
    //Check if there is a coin that is the same as change requested
    for(int i = 0; i < coinsSize; i++)
    {
        if (coins[i] == changeRequested)
        {
            coinCount[i]++; //if coin = change, then increment count of coin
            return coinCount;
        }
    }
    
    int min = std::numeric_limits<int>::max();
    
    //Loop through each coin
    for(int i = 0; i < coinsSize; i++)
    {
        //Only use coins that are less than change requested
        if(coins[i] < changeRequested)
        {
            //Minimum coins for i
            std::vector<int> subProblem1 = changeslowDC(coins, coins[i], coinsSize);
            // Minimum coins for K - i
            std::vector<int> subProblem2 = changeslowDC(coins, changeRequested - coins[i], coinsSize);
            
            int minCount = elementSum(subProblem1, subProblem2);
            
            //New minmum coins
            if(minCount < min)
            {
                min = minCount;
                for(int j = 0; j < coinsSize; j++) //Update coin count
                    coinCount[j] = subProblem1[j] + subProblem2[j];
            }
        }
    }
    return coinCount;
}

/****************************************************************************************
 ** Description: Sums up values in each element of both vectors
 ** Parameters:  vector<int> vect1, vector<int> vect2
 ** Pre-Conditions: Both vectors must contain ints
 ** Post-Conditions: Returns sum of all elements in boths vectors
 ****************************************************************************************/
static int elementSum(std::vector<int> vect1, std::vector<int> vect2){
    int sum = 0;
    for(int i = 0; i < vect1.size(); i++)
        sum += vect1[i] + vect2[i];
    return sum;
}
